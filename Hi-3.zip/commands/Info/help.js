const { MessageEmbed, MessageActionRow, MessageButton } = require("discord.js");
const config = require("../../botconfig/config.json");
const ee = require("../../botconfig/embed.json");
const emoji = require("../../botconfig/emojis.json");


module.exports = {
  name: "help",
  category: "Info",
  description: "Music Disc",
  run: async (client, message, args, guildData, player, prefix) => {
    try {

      


      const mainmenu = new MessageEmbed()
        .setAuthor("Music Disc Help Panel", "https://media.discordapp.net/attachments/910733222621630504/912731510413623338/20211123_211721.jpg")
      .setThumbnail(message.author.displayAvatarURL()) 
        .setDescription(`Hey! This is Music Disc. Am here to provide you 24/7 high quality music.`)
        .addField(`<a:aSetting:917418996721152030> ● Config [9]`, `\`24/7\`, \`adddj\`, \`removedj\`, \`prefix\`, \`reset\`, \`toggledjonlycmd\`, \`togglepruning\`, \`setting\`, \`announce\``)
        .addField(`<a:filters:917419246194131055> ● Filters [15]`, `\`8d\`, \`bassboost\`, \`chipmunk \`, \`clearreq\`, \`darthvader\`, \`nightcore\`, \`slowmo\`, \`speed\`, \`tremolo\`, \`clearfilter\`, \`vibarate\`, \`vibrato\`, \`equalizer\`, \`pitch\`, \`rate\``)
        .addField(`<a:music:917419620296695818> ● Music [27]`, `\`autoplay\`, \`back\`,  \`clearqueue\`, \`forward\`, \`grab\`, \`join\`, \`loop\`, \`movebot\`, \`moveme\`, \`movetrack\`, \`nowplaying\`, \`pause\`, \`play\`, \`playtop\`, \`queue\`, \`remove\`, \`replay\`, \`resume\`, \`rewind\`, \`search\`, \`seek\`, \`shuffle\`, \`skip\`, \`skipto\`, \`stop\`, \`volume\`, \`voteskip\``)
        .addField(`<a:ownerop:917429019836809277> ● Owner [7]`, `\`reload\`, \`eval\`, \`status\`, \`leaveguild\`, \`execute\`, \`server-list\`, \`reboot\``)
        .addField(`<a:diamond:917420144622448660> ● Premium [2]`, `\`addpremium\`, \`removepremium\``)
        .addField(`<a:info:917418506377629736> ● Info [6]`, `\`djmode\`, \`help\`, \`invite\`,  \`ping\`, \`stats\`, \`uptime\``)
        .addField(`<a:link:917420433136025671> ● Links [2]`, `[Invite Me](https://discord.com/api/oauth2/authorize?client_id=904255428500807690&permissions=8&scope=bot) | [Support Server](https://discord.gg/DdBnR2cw3V)`)
        .setTimestamp()
        .setFooter(ee.footertext)
       .setColor(`#FFFF00`)
      
 let buttonrow1 = new MessageActionRow()
      .addComponents(
        new MessageButton()
        .setStyle('LINK')
        .setURL('https://replit.com/@Slow-and-Steady/Music-Disc-2#commands/Info/help.js')
      .setLabel('Test')
    );
      

      message.channel.send({ embeds: [mainmenu] })
    } catch (e) {
      console.log(String(e.stack).bgRed)
      const emesdf = new MessageEmbed()
        .setColor(ee.wrongcolor)
        .setAuthor(`An Error Occurred`)
        .setDescription(`\`\`\`${e.message}\`\`\``);
			return message.channel.send({embeds: [emesdf]});
        }
    }
}