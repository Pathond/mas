module.exports = (client) => {
    require("./erela_events/creation")(client)
};